import unittest
from import_random import Character, Goblin, Orc

class TestRPG(unittest.TestCase):

    # Test that taking damage correctly reduces HP
    def test_hp_reduces(self):
        p = Character("Aun", hp=100)
        p.take_damage(10)
        self.assertEqual(p.hp, 90)

    # Test alive/dead status based on HP value
    def test_is_alive(self):
        p = Character("Aun", hp=1)
        self.assertTrue(p.is_alive())   # HP above 0 → alive
        p.hp = 0
        self.assertFalse(p.is_alive())  # HP 0 → not alive

    # Test adding a single item to inventory
    def test_inventory_add(self):
        p = Character("Aun")
        p.inventory.append({"name": "Iron Ore"})
        self.assertEqual(len(p.inventory), 1)

    # Test adding multiple items to inventory
    def test_inventory_multiple_items(self):
        p = Character("Aun")
        p.inventory.append({"name": "Iron Ore"})
        p.inventory.append({"name": "Leather"})
        self.assertEqual(len(p.inventory), 2)

    # Test Goblin default stats
    def test_goblin_stats(self):
        g = Goblin("Goblin")
        self.assertEqual(g.attack_power, 6)
        self.assertEqual(g.defence, 1)

    # Test Orc default stats
    def test_orc_stats(self):
        o = Orc("Orc")
        self.assertEqual(o.attack_power, 10)
        self.assertEqual(o.defence, 3)

if __name__ == "__main__":
    unittest.main()
