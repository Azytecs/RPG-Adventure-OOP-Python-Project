import random
import json

# Save all player attributes into a JSON file
def save_game(player):
    data = {
        "name": player.name,
        "hp": player.hp,
        "max_hp": player.max_hp,
        "attack_power": player.attack_power,
        "defend": player.defend,
        "potion": player.potion,
        "item": player.item,
        "temp_buff": player.temp_buff,
        "buff_uses": player.buff_uses,
        "buff_cooldown": player.buff_cooldown,
        "inventory": player.inventory
    }

    try:
        # Write the dictionary to a file
        with open("savefile.json", "w") as f:
            json.dump(data, f)
        print("Game saved.")
    except:
        print("Error: Could not save the game.")

# Load player data and rebuild the Character object
def load_game():
    try:
        with open("savefile.json", "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        print("No save file found.")
        return None
    except json.JSONDecodeError:
        print("Save file is corrupted.")
        return None

    # Reconstruct player using stored values
    player = Character(data["name"])
    player.hp = data["hp"]
    player.max_hp = data["max_hp"]
    player.attack_power = data["attack_power"]
    player.defend = data["defend"]
    player.potion = data["potion"]
    player.item = data["item"]
    player.temp_buff = data["temp_buff"]
    player.buff_uses = data["buff_uses"]
    player.buff_cooldown = data["buff_cooldown"]
    player.inventory = data["inventory"]

    print("Game loaded.")
    return player


class Character:
    # Initialise core player attributes
    def __init__(self, name, hp=100, attack_power=12, defend=False, potion=1, item=None, temp_buff=None):
        self.name = name
        self.hp = hp
        self.attack_power = attack_power
        self.defend = defend
        self.potion = potion
        self.max_hp = hp

        self.item = item
        self.temp_buff = temp_buff
        self.extra_damage = 0

        self.buff_uses = 3
        self.buff_cooldown = 0

        self.inventory = []

    # Calculate attack damage including buffs and crit chance
    def attack(self):
        # Apply temporary buff once
        if self.temp_buff == "Energy Fragment":
            self.extra_damage = random.randint(1, 2)
            self.temp_buff = None

        if self.temp_buff == "Orcish Relic":
            self.extra_damage = random.randint(3, 5)
            self.temp_buff = None

        base = self.attack_power + self.extra_damage

        # Armour set adds flat bonus
        if self.item == "Armour Set":
            base += 3

        # Critical hit chance
        if random.random() <= 0.08:
            return base * 2
        return base

    # Check if character is alive
    def is_alive(self):
        return self.hp > 0

    # Apply incoming damage with dodge, defend, and armour effects
    def take_damage(self, amount):
        # Small chance to dodge completely
        if random.random() <= 0.04:
            amount = 0

        # Defend halves incoming damage once
        if self.defend:
            amount -= amount / 2
            self.defend = False

        # Armour reduces damage
        if self.item == "Armour Set":
            amount -= 3

        self.hp -= amount

        # Prevent negative HP
        if self.hp < 0:
            self.hp = 0

    def __str__(self):
        return f"{self.name} (HP: {self.hp})"


class Goblin(Character):
    # Initialise Goblin-specific stats
    def __init__(self, name, hp=80, attack_power=6, defence=1, behaviour=None):
        super().__init__(name, hp)
        self.attack_power = attack_power
        self.defence = defence
        self.behaviour = behaviour

    # Decide whether to flee or attack
    def take_turn(self):
        if self.hp <= 50:
            return "flee"
        return "attack"

    # Basic Goblin attack
    def attack(self):
        if random.random() <= 0.08:
            return self.attack_power * 2
        return self.attack_power

    # Goblin special attack (high burst)
    def special_attack(self):
        return self.attack_power * 4

    # Apply defence reduction
    def take_damage(self, amount):
        if random.random() <= 0.04:
            amount = 0

        reduced = max(0, amount - self.defence)
        self.hp -= reduced

        if self.hp < 0:
            self.hp = 0


class Orc(Character):
    # Initialise Orc-specific stats
    def __init__(self, name, hp=130, attack_power=10, defence=3, behaviour=None):
        super().__init__(name, hp)
        self.attack_power = attack_power
        self.defence = defence
        self.behaviour = behaviour

    # Decide whether to attack or enter rage mode
    def take_turn(self):
        if self.hp <= 40:
            return "rage"
        return "attack"

    # Basic Orc attack
    def attack(self):
        # Armour set modifies Orc damage
        if self.item == "Armour Set":
            if random.random() <= 0.08:
                return (self.attack_power + 3) * 2
            return self.attack_power + 3

        if random.random() <= 0.08:
            return self.attack_power * 2
        return self.attack_power

    # Orc special attack (rage mode)
    def special_attack(self):
        return self.attack_power * 2

    # Apply defence reduction
    def take_damage(self, amount):
        if random.random() <= 0.04:
            amount = 0

        reduced = max(0, amount - self.defence)
        self.hp -= reduced

        if self.hp < 0:
            self.hp = 0


# Handle random temporary buffs after combat
def random_item_drop(player, enemy):
    # Chance for common buff
    if random.random() < 0.12:
        print("A strange force coils around your weapon… your next attack grows sharper.")

        while True:
            choice = input("1.Accept\n2.Decline\n3.Inspect\n")

            if choice == "1":
                player.temp_buff = "Energy Fragment"
                print("You accept the energy. Your next attack gains +1 to +2 damage.")
                break

            elif choice == "2":
                print("You decline the mysterious energy.")
                break

            elif choice == "3":
                print("\n--- Item Inspection ---")
                print("Energy Fragment: +1 to +2 next attack\n")

            else:
                print("Invalid choice.")

    # Rare Orc-only buff
    if isinstance(enemy, Orc) and random.random() < 0.04:
        print("An Orcish relic drops from the enemy… it radiates violent power.")

        while True:
            choice = input("1.Accept\n2.Decline\n3.Inspect\n")

            if choice == "1":
                player.temp_buff = "Orcish Relic"

                heal_amount = random.randint(10, 30)
                player.hp = min(player.hp + heal_amount, player.max_hp)

                print(f"You absorb the relic’s power! +3 to +5 damage next attack and +{heal_amount} HP restored.")
                break

            elif choice == "2":
                print("You leave the relic untouched.")
                break

            elif choice == "3":
                print("\n--- Item Inspection ---")
                print("Orcish Relic: +3 to +5 next attack, restores 10–30 HP\n")

            else:
                print("Invalid choice.")


# Handle potions and temporary stat boosts
def use_consumable(player):
    choice = input("1.Health Potions\n2.Temporary stat boost\n")

    # Use a health potion
    if choice == "1":
        if player.potion > 0:
            heal_amount = 40
            player.hp = min(player.hp + heal_amount, player.max_hp)
            player.potion -= 1
            print(f"You healed for {heal_amount}.")
        else:
            print("No potions left.")
        return

    # Use temporary buff
    if choice == "2":
        if player.buff_cooldown > 0:
            print(f"Buff is on cooldown for {player.buff_cooldown} turns.")
            return

        if player.buff_uses == 0:
            print("No buff uses left. Cooldown started.")
            player.buff_cooldown = 3
            player.buff_uses = 3
            return

        player.attack_power += 1
        player.hp = min(player.hp + 3, player.max_hp)
        player.buff_uses -= 1
        print(f"Buff used. Remaining uses: {player.buff_uses}")


# Add item to inventory
def add_inventory(player, item):
    player.inventory.append(item)

# Remove item by name
def remove_inventory(player, item_name):
    for item in player.inventory:
        if item["name"] == item_name:
            player.inventory.remove(item)
            return True
    return False


# Generate random materials during exploration
def generate_explore_item(player):
    roll = random.random()

    if roll < 0.25:
        add_inventory(player, {"name": "Iron Ore", "desc": "Chunk of raw metal.", "category": "Material"})
        print("You mine some Iron Ore.")

    elif roll < 0.45:
        add_inventory(player, {"name": "Leather", "desc": "Tough hide used for armour.", "category": "Material"})
        print("You find torn Leather scraps.")

    elif roll < 0.60:
        add_inventory(player, {"name": "Wood", "desc": "Basic crafting material.", "category": "Material"})
        print("You gather some Wood.")

    elif roll < 0.68:
        add_inventory(player, {"name": "Vial", "desc": "Empty crafting bottle.", "category": "Material"})
        print("You find a dusty Vial.")

    elif roll < 0.80:
        add_inventory(player, {"name": "Herbs", "desc": "Medicinal plant.", "category": "Material"})
        print("You discover rare glowing Herbs.")

    else:
        print("You found nothing this time.")


# Craft items using materials
def crafting(player):
    print("\n=== Crafting Menu ===")
    print("Your Materials:")
    for i, item in enumerate(player.inventory, start=1):
        print(f"{i}. {item['name']}")

    print("\nCraftable Items:")
    print("1. Health Potion")
    print("2. Strong Health Potion")
    print("3. Sharpening Oil")
    print("4. Iron Sword")
    print("5. Leather Armour")
    print("6. Back")

    choice = input("Choose your recipe: ")

    # Health Potion
    if choice == "1":
        if remove_inventory(player, "Herbs") and remove_inventory(player, "Vial"):
            add_inventory(player, {"name": "Health Potion", "desc": "Restores 40 HP.", "category": "Consumable"})
            print("You crafted a Health Potion.")
        else:
            print("You need: Herbs + Vial.")

    # Strong Health Potion
    elif choice == "2":
        if remove_inventory(player, "Herbs") and remove_inventory(player, "Herbs") and remove_inventory(player, "Vial"):
            add_inventory(player, {"name": "Strong Health Potion", "desc": "Restores 80 HP.", "category": "Consumable"})
            print("You crafted a Strong Health Potion.")
        else:
            print("You need: 2x Herbs + Vial.")

    # Sharpening Oil
    elif choice == "3":
        if remove_inventory(player, "Herbs") and remove_inventory(player, "Leather"):
            add_inventory(player, {"name": "Sharpening Oil", "desc": "Slight attack boost.", "category": "Consumable"})
            print("You crafted Sharpening Oil.")
        else:
            print("You need: Herbs + Leather.")

    # Iron Sword
    elif choice == "4":
        if remove_inventory(player, "Iron Ore") and remove_inventory(player, "Wood"):
            add_inventory(player, {"name": "Iron Sword", "desc": "Basic iron weapon.", "category": "Weapon"})
            print("You forged an Iron Sword.")
        else:
            print("You need: Iron Ore + Wood.")

    # Leather Armour
    elif choice == "5":
        if remove_inventory(player, "Leather") and remove_inventory(player, "Leather"):
            add_inventory(player, {"name": "Leather Armour", "desc": "Light armour.", "category": "Armour"})
            print("You crafted Leather Armour.")
        else:
            print("You need: 2x Leather.")

    elif choice == "6":
        print("Returning to menu...")

    else:
        print("Invalid choice.")


# Main combat loop
def combat(player, enemy):
    print(f"\nA wild {enemy.name} appears!")

    while player.is_alive() and enemy.is_alive():

        # Reduce buff cooldown each turn
        if player.buff_cooldown > 0:
            player.buff_cooldown -= 1

        print(f"\n{player.name} HP: {player.hp}")
        print(f"{enemy.name} HP: {enemy.hp}")

        print("\nChoose your action:")
        choice = input("1.Attack\n2.Defend\n3.Equip Item\n4.Use Consumable\n")

        # Player attack
        if choice == "1":
            random_item_drop(player, enemy)
            damage = player.attack()
            enemy.take_damage(damage)
            print(f"You dealt {damage} damage.")

            if not enemy.is_alive():
                print(f"{enemy.name} defeated!")
                break

        # Player defend
        elif choice == "2":
            random_item_drop(player, enemy)
            player.defend = True
            print("You brace for impact.")

        # Equip armour
        elif choice == "3":
            if player.item is None:
                player.item = "Armour Set"
                print("You equipped the Armour Set.")
            else:
                print("Item already equipped.")

        # Use consumable
        elif choice == "4":
            use_consumable(player)

        else:
            print("Invalid choice.")
            continue

        # Enemy turn
        if enemy.is_alive():
            action = enemy.take_turn()

            # Goblin flee behaviour
            if action == "flee":
                print(f"The {enemy.name} fled the battle!")
                break

            # Standard attack behaviour
            elif action == "attack":
                # Goblin has 10% chance to use special attack
                if isinstance(enemy, Goblin) and random.random() < 0.10:
                    enemy_damage = enemy.special_attack()
                    print(f"The {enemy.name} unleashes a special attack!")
                else:
                    enemy_damage = enemy.attack()

                player.take_damage(enemy_damage)
                print(f"The {enemy.name} hits you for {enemy_damage} damage.")

            # Orc rage behaviour
            elif action == "rage":
                enemy_damage = enemy.special_attack()
                print(f"The {enemy.name} enters a rage and uses a special attack!")
                player.take_damage(enemy_damage)
                print(f"The {enemy.name} hits you for {enemy_damage} damage.")

            # Check if player died
            if not player.is_alive():
                print("You have been defeated...")
                break


# Display main menu options
def main_menu():
    print("\n=== RPG Adventure ===")
    print("1. Start Game")
    print("2. Load Game")
    print("3. Exit")
    return input("Choose an option: ")


# Core game loop
def game_loop(player):
    print(f"\nWelcome, {player.name}!")

    while player.is_alive():
        print(f"\n{player}")
        print("1. Explore 🌿")
        print("2. Raid ⚔️")
        print("3. Craft 🔧")
        print("4. Inventory 🎒")
        print("5. Save Game 💾")
        print("6. Quit ❌")


        choice = input("What do you do? ")

        if choice == "1":
            generate_explore_item(player)

        elif choice == "2":
            if random.random() < 0.5:
                enemy = Goblin("Goblin")
            else:
                enemy = Orc("Orc")
            combat(player, enemy)

        elif choice == "3":
            crafting(player)

        elif choice == "4":
            for index, item in enumerate(player.inventory, start=1):
                print(f"{index}. {item['name']} - {item['desc']} ({item['category']})")

        elif choice == "5":
            save_game(player)

        elif choice == "6":
            print("Goodbye!")
            break

        else:
            print("Invalid choice.")

    if not player.is_alive():
        print("Game Over.")


# Entry point
def main():
    while True:
        choice = main_menu()

        if choice == "1":
            name = input("Enter your character's name: ")
            player = Character(name)
            game_loop(player)

        elif choice == "2":
            player = load_game()
            if player:
                game_loop(player)

        elif choice == "3":
            print("Thanks for playing!")
            break

        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
